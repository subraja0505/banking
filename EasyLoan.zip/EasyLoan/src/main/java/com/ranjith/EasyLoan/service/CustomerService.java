package com.ranjith.EasyLoan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ranjith.EasyLoan.DAO.CustomerLoanRepository;
import com.ranjith.EasyLoan.DAO.CustomerRepository;
import com.ranjith.EasyLoan.model.Customer;
import com.ranjith.EasyLoan.model.CustomerLoan;

@Service
public class CustomerService {
	private Customer customer;
	private static Integer number = 1;
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private CustomerLoanRepository customerLoanRepo;
	public Customer createCustomer() {
		customer = new Customer();
		StringBuilder str = new StringBuilder(Integer.toString(1000 + number++));
		str.deleteCharAt(0);
		String accountNo = "RBI" + str;
		customer.setAccountNo(accountNo.toString());
		return customer;
	}

	public Customer validateLogIn(Customer customer) {
		Customer exists = customerRepo.getOne(customer.getAccountNo());
		if (exists != null && exists.getName().equalsIgnoreCase(customer.getName())
				&& exists.getPassword().equalsIgnoreCase(customer.getPassword()))
			return exists;
		return null;
	}

	public boolean pay(String id) {
		CustomerLoan cl = customerLoanRepo.getOne(id);
		cl.setRemainingTerm(cl.getRemainingTerm() - 1);
		cl.setBalanceAmount(cl.getAmount() - cl.getEmi());
		customerLoanRepo.save(cl);
		return false;
	}
}
