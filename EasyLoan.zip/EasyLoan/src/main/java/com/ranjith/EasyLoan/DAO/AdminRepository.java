package com.ranjith.EasyLoan.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ranjith.EasyLoan.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, String> {

}
