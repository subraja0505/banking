package com.ranjith.EasyLoan.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ranjith.EasyLoan.model.Loan;

public interface LoanRepository extends JpaRepository<Loan, String> {

}
