package com.ranjith.EasyLoan.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ranjith.EasyLoan.model.CustomerLoan;

public interface CustomerLoanRepository extends JpaRepository<CustomerLoan, String> {

}
