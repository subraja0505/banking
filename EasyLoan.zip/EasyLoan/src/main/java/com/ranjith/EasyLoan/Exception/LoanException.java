package com.ranjith.EasyLoan.Exception;

public class LoanException extends Exception {
	public LoanException(String message)
	{
		super(message);
	}

}
