package com.ranjith.EasyLoan.controller;

import java.util.LinkedList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ranjith.EasyLoan.DAO.CustomerLoanRepository;
import com.ranjith.EasyLoan.DAO.CustomerRepository;
import com.ranjith.EasyLoan.DAO.LoanRepository;
import com.ranjith.EasyLoan.Exception.LoanException;
import com.ranjith.EasyLoan.model.Admin;
import com.ranjith.EasyLoan.model.Customer;
import com.ranjith.EasyLoan.model.CustomerLoan;
import com.ranjith.EasyLoan.model.Loan;
import com.ranjith.EasyLoan.service.CustomerService;
import com.ranjith.EasyLoan.service.LoanService;

@Controller
public class HomeController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private CustomerRepository customerRepo;
	@GetMapping("/")
	public String toWelcomePage()
	{
		return "welcomePage";
	}
	@GetMapping("/customerSignUp")
	public String toCustomerSignUp(Model m)
	{
		Customer customer = customerService.createCustomer();
		m.addAttribute("customer", customer);
		return "customerSignUp";
	}
	@GetMapping("/customerSignIn")
	public String toCustomerSignIn(Model m)
	{
		Customer customer = new Customer();
		m.addAttribute("customer", customer);
		return "customerSignIn";
	}
	@PostMapping("/customerSignUp")
	public String toNewDashboard(@Valid Customer customer, BindingResult bindingResult, Model m)
	{
		if(!bindingResult.hasErrors())
		{
		customerRepo.save(customer);
		m.addAttribute("customer", customer);
		m.addAttribute("loans", loanRepo.findAll());
		return "dashboard";
		}
		return "customerSignUp";
	}
	@PostMapping("/customerSignIn")
	public String toDashboard(Customer customer, Model m)
	{
		Customer exist = customerService.validateLogIn(customer);
		if(exist == null)
		{
			m.addAttribute("message", "Invalid Login Details");
			return "customerSignIn";
		}
		m.addAttribute("customer", exist);
		m.addAttribute("loans", loanRepo.findAll());
		return "dashboard";
	}
	@GetMapping("/adminLogin")
	public String toAdminPage(Model m)
	{  
		m.addAttribute("admin", new Admin());
		return "adminPage";
	}
	@Autowired
	private LoanRepository loanRepo;
	@Autowired
	private LoanService loanService;
	@RequestMapping("/bankPage")
	public String toBankPage(Admin admin, Model m)
	{ 
		System.out.println(admin);
		if(admin.getAdminId()== null ||("admin".equalsIgnoreCase(admin.getAdminId()) && "password".equals(admin.getPassword())))
		{
			m.addAttribute("loans", loanRepo.findAll());
			m.addAttribute("loan", loanService.createLoan());
			return "bankPage";
		}
		m.addAttribute("message", "invalid login");
		return "adminPage";
	}
	@PostMapping("/addLoan")
	public String addingLoan(@Valid Loan loan, BindingResult result, Model m)
	{
		if(!result.hasErrors())
		{
		loanRepo.save(loan);
		return "redirect:/bankPage";
		}
		return "bankPage";
	}
	@GetMapping("/applyLoan")
	public String applyLoan(@RequestParam String loanId,  String customerId, Model m)
	{
		CustomerLoan customerLoan = loanService.createCustomerLoan(loanId, customerId);
		m.addAttribute("customerLoan", customerLoan);
		return "applyLoan";
	}
	@Autowired
	private CustomerLoanRepository customerLoanRepo;
	@PostMapping("/applyLoan")
	public String applyLoanSuccess(@Valid CustomerLoan customerLoan, BindingResult result, Model m)
	{
		if(!result.hasErrors())
		{
		String id = customerLoan.getCustomerLoanId();
		String customerId = "RBI" +  id.charAt(0) + id.charAt(1) + id.charAt(2);
		String loanId     = "LID" +  id.charAt(3) + id.charAt(4) + id.charAt(5);
		Customer customer = customerRepo.getOne(customerId);
		Loan loan = loanRepo.getOne(loanId);
		if(loan.getRole().toLowerCase().contains(customer.getProfession().toLowerCase()))
		{
		loan.setCustomerLoanId(id);
		customer.setCustomerLoanId(id);
		loanService.emiCalculator(customerLoan);
		customerLoan.setRemainingTerm(customerLoan.getTotalLoanTerm());
		customerLoan.setBalanceAmount(customerLoan.getAmount());
		customerLoanRepo.save(customerLoan);
		m.addAttribute("message", "loan applied successfully");
		return "success";
		}
		m.addAttribute("message", "Sorry, you are not eligible for this loan");
		return "errorPage";
		}
		return "errorPage";
	}
	@GetMapping("/getCustomer")
	public String customerLoansList(@RequestParam String loanId, Model m)
	{
		List<CustomerLoan> cl = new LinkedList();
		for(CustomerLoan l : customerLoanRepo.findAll())
		{
			if(l.getCustomerLoanId().substring(3).equals(loanId.substring(3)))
			{
				cl.add(l);
			}
		}
		if(cl.isEmpty())
		{
			m.addAttribute("message", "no customers apply this loan");
			return "errorPage";
		}
		m.addAttribute("customerLoans", cl);
		return "customerLoansList";
	}
	@GetMapping("/showLoans")
	public String showEnrolledLoans(@RequestParam String customerId, Model m)
	{
		List<CustomerLoan> cl = new LinkedList();
		for(CustomerLoan l : customerLoanRepo.findAll())
		{
			if(l.getCustomerLoanId().substring(0,3).equals(customerId.substring(3)))
			{
				cl.add(l);
			}
		}
		if(cl.isEmpty())
		{
			m.addAttribute("message", "no loans applied");
			return "errorPage";
		}
		m.addAttribute("customerLoans", cl);
		return "appliedLoans";
	}
	@GetMapping("/pay")
	public String paymentFunc(String customerLoanId, Model m)
	{
		boolean result = customerService.pay(customerLoanId);
		m.addAttribute("message", "paid successfully");
		return "success";
	}
}
