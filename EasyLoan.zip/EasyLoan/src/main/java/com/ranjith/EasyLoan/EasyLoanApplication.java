package com.ranjith.EasyLoan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasyLoanApplication {

	public static void main(String[] args) {
		SpringApplication.run(EasyLoanApplication.class, args);
	}

}
