package com.ranjith.EasyLoan.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class Loan {
	@Id
	@Pattern(regexp="\\W*((?i)LID(?-i))\\W*[0-9]{3}$", message="invalid loanId")
	@Size(max=6)
	private String loanId;
	@Pattern(regexp = "[a-zA-Z ]+\\.?", message="invalid type")
	private String type;
	@Min(value=2_00_000, message="amount is too small")
	private double minimumAmount;
	@Min(value=4_00_000, message="amount is too small")
	@Max(value=20_00_000, message="amount is too large")
	private double maximumAmount;
	@Pattern(regexp = "[a-zA-Z ]+\\.?", message="invalid role")
	private String role;
	@Min(value=2, message="too small")
	@Max(value=20, message="too large")
	private double interest;
	@Min(value=2, message="too small")
	@Max(value=10, message="too large")
	private int loanTerm;
	private String customerLoanId;
	public Loan()
	{
		
	}
	public Loan(String loanId, String type, double minimumAmount, Double maximumAmount, String role, double interest,
			int loanTerm, String customerLoanId) {
		super();
		this.loanId = loanId;
		this.type = type;
		this.minimumAmount = minimumAmount;
		this.maximumAmount = maximumAmount;
		this.role = role;
		this.interest = interest;
		this.loanTerm = loanTerm;
		this.customerLoanId = customerLoanId;
	}
	public String getLoanId() {
		return loanId;
	}
	public void setLoanId(String loanId) {
		this.loanId = loanId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getMinimumAmount() {
		return minimumAmount;
	}
	public void setMinimumAmount(double minimumAmount) {
		this.minimumAmount = minimumAmount;
	}
	public Double getMaximumAmount() {
		return maximumAmount;
	}
	public void setMaximumAmount(Double maximumAmount) {
		this.maximumAmount = maximumAmount;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public double getInterest() {
		return interest;
	}
	public void setInterest(double interest) {
		this.interest = interest;
	}
	public int getLoanTerm() {
		return loanTerm;
	}
	public void setLoanTerm(int loanTerm) {
		this.loanTerm = loanTerm;
	}
	public String getCustomerLoanId() {
		return customerLoanId;
	}
	public void setCustomerLoanId(String customerLoanID) {
		this.customerLoanId = customerLoanID;
	}
	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", type=" + type + ", minimumAmount=" + minimumAmount + ", maximumAmount="
				+ maximumAmount + ", role=" + role + ", interest=" + interest + ", loanTerm=" + loanTerm
				+ ", customerLoanID=" + customerLoanId + "]";
	}
	

}
