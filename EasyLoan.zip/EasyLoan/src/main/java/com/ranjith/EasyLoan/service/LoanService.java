package com.ranjith.EasyLoan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ranjith.EasyLoan.DAO.LoanRepository;
import com.ranjith.EasyLoan.model.CustomerLoan;
import com.ranjith.EasyLoan.model.Loan;

@Service
public class LoanService {
	private Loan loan;
	private static Integer number = 1;
	@Autowired
	private LoanRepository loanRepo;

	public Loan createLoan() {
		loan = new Loan();
		StringBuilder str = new StringBuilder(Integer.toString(1000 + number++));
		str.deleteCharAt(0);
		String id = "LID" + str;
		loan.setLoanId(id);
		return loan;
	}

	public CustomerLoan createCustomerLoan(String loanId, String customerId) {
		CustomerLoan customerLoan = new CustomerLoan();
		customerLoan.createCustomerLoanId(customerId, loanId);
		Loan loan = loanRepo.getOne(loanId);
		customerLoan.setLoanType(loan.getType());
		customerLoan.setInterest(loan.getInterest());
		customerLoan.setTotalLoanTerm(loan.getLoanTerm());
		return customerLoan;
	}

	public void emiCalculator(CustomerLoan customerLoan) {
		    double emi; 
		    double principle = customerLoan.getAmount();
		    double r = customerLoan.getInterest();
		    double year = customerLoan.getTotalLoanTerm();
		    double rate = r / (12 * 100); // one month interest 
		    double month = year * 12; // one month period 
		    emi = (principle * rate * (float)Math.pow(1 + rate, month))  
	                / (float)(Math.pow(1 + rate, month) - 1); 
		   customerLoan.setEmi(emi);
		
	}

}
