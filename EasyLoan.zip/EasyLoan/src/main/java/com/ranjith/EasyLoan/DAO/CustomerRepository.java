package com.ranjith.EasyLoan.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ranjith.EasyLoan.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, String> {

}
