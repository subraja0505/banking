package com.ranjith.EasyLoan.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class Customer {
	@Id
	@Pattern(regexp="\\W*((?i)RBI(?-i))\\W*[0-9]{3}$", message="invalid accountNo")
	@Size(max=6)
	private String accountNo;
	@Pattern(regexp = "[a-zA-Z ]+\\.?", message="invalid name format")
	private String name;
	@Pattern(regexp="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,20}$", message="password is too weak")
	private String password;
	@Pattern(regexp="^\\d{10}$", message="doesn't seem to be a valid phone number")
	private String phoneNo;
	@Size(min=1, message="not to be an empty field")
	private String address;
	private double accountBalance=2_00_000;
	@Pattern(regexp = "[a-zA-Z]+\\.?", message="invalid profession")
	private String profession;
	@Min(value=1000, message="invalid income details")
	private double income;
	private String customerLoanId;
	public Customer()
	{
		
	}
	public Customer(@Size(max = 6) String accountNo, String name, String password, String phoneNo, String address,
			double accountBalance, String profession, double income, String customerLoanId) {
		super();
		this.accountNo = accountNo;
		this.name = name;
		this.password = password;
		this.phoneNo = phoneNo;
		this.address = address;
		this.accountBalance = accountBalance;
		this.profession = profession;
		this.income = income;
		this.customerLoanId = customerLoanId;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	public double getIncome() {
		return income;
	}
	public void setIncome(double income) {
		this.income = income;
	}
	
	public String getCustomerLoanId() {
		return customerLoanId;
	}
	public void setCustomerLoanId(String customerLoanId) {
		this.customerLoanId = customerLoanId;
	}
	@Override
	public String toString() {
		return "Customer [accountNo=" + accountNo + ", name=" + name + ", password=" + password + ", phoneNo=" + phoneNo
				+ ", address=" + address + ", accountBalance=" + accountBalance + ", profession=" + profession
				+ ", income=" + income + ", customerLoanId=" + customerLoanId + "]";
	}

}
