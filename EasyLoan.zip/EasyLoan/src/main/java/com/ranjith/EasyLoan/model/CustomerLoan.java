package com.ranjith.EasyLoan.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class CustomerLoan {
	@Id
	@Pattern(regexp="[0-9]{6}$", message="invalid customerLoanId")
	@Size(max=6)
	private String customerLoanId;
	@Pattern(regexp = "[a-zA-Z ]+\\.?", message="invalid type")
	private String loanType;
	@Min(value=1, message="not to be empty")
	private double amount;
	private double balanceAmount;
	@Min(value=1, message="interest is too low")
	@Max(value=20, message="interest is too high")
	private double interest;
	@Min(value=1, message="years are too low")
	@Max(value=10, message="years are too high")
	private int totalLoanTerm;
	private int remainingTerm;
	private double emi;
	public CustomerLoan()
	{
		
	}
	public CustomerLoan(String customerLoanId, String loanType, Double amount, double balanceAmount, double interest,
			int totalLoanTerm, int remainingTerm, double emi) {
		super();
		this.customerLoanId = customerLoanId;
		this.loanType = loanType;
		this.amount = amount;
		this.balanceAmount = balanceAmount;
		this.interest = interest;
		this.totalLoanTerm = totalLoanTerm;
		this.remainingTerm = remainingTerm;
		this.emi = emi;
	}
	public String getCustomerLoanId() {
		return customerLoanId;
	}
	public void setCustomerLoanId(String customerLoanId) {
		this.customerLoanId = customerLoanId;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public double getBalanceAmount() {
		return balanceAmount;
	}
	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	public double getInterest() {
		return interest;
	}
	public void setInterest(double interest) {
		this.interest = interest;
	}
	public int getTotalLoanTerm() {
		return totalLoanTerm;
	}
	public void setTotalLoanTerm(int totalLoanTerm) {
		this.totalLoanTerm = totalLoanTerm;
	}
	public int getRemainingTerm() {
		return remainingTerm;
	}
	public void setRemainingTerm(int remainingTerm) {
		this.remainingTerm = remainingTerm;
	}
	public double getEmi() {
		return emi;
	}
	public void setEmi(double emi) {
		this.emi = emi;
	}
	@Override
	public String toString() {
		return "CustomerLoan [customerLoanId=" + customerLoanId + ", loanType=" + loanType + ", amount=" + amount
				+ ", balanceAmount=" + balanceAmount + ", interest=" + interest + ", totalLoanTerm=" + totalLoanTerm
				+ ", remainingTerm=" + remainingTerm + ", emi=" + emi + "]";
	}
	public void createCustomerLoanId(String customerId, String loanId) {
		char[] one = customerId.toCharArray();
		char[] two = loanId.toCharArray();
		this.customerLoanId = ""+one[3] + one[4] + one[5] + two[3] + two[4] + two[5];
	}

}
